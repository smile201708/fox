import { playSound } from '../utils/play_alarm.js'
playSound()